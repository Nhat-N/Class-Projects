﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CCS2._0.Models
{
    public class DecadeModel
    {
       
        public int SchoolYearBegin { get; set; }
        public string Grade { get; set; }
        public string TeacherName { get; set; }

    }
}
