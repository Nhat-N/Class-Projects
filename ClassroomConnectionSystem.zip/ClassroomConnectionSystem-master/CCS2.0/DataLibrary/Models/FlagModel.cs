﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibrary.Models
{
    public class FlagModel
    {
        public int CommentId { get; set; }
        public string Reason { get; set; }
    }
}
