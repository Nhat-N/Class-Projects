import java.io.*;
import java.net.Socket;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Client {

    private static long turnAround;


    public static void main(String[] args) throws InterruptedException {
    Scanner input = new Scanner(System.in);

      System.out.println("Type hostname you wish to use.");
      String host = input.next();


      System.out.println("Please type the port you wish to use.");
      int port = Integer.parseInt(input.next());


        System.out.println("Please type what operation you would like to request.\n1. Data & time\n2. Uptime\n3. Memory use\n4. Netstat\n5. Current users\n6. Running processes");
        int operation = input.nextInt();

        while(operation < 1 || operation > 6){
            System.out.println("Invalid choice, please pick from 1-6.");
            operation = input.nextInt();
        }

        System.out.println("Please pick the number of client requests to send to the server.");
        int numClient = input.nextInt();

        List<Thread> threadList = new ArrayList<>();

        for(int i = 1; i <= numClient; i++){
            Thread reqThread = new Request(port, host, operation, "Client number " + i);
            reqThread.start();
            threadList.add(reqThread);
        }

        for(Thread i : threadList) {
            i.join();
        }

        System.out.println("----------------------------------------------------------------------------\nTotal turn around time: "+ turnAround +" ms."+ " Average turn around time: "+ turnAround/numClient+" ms.");

    }

    public static void calculate(long time){
        turnAround += time;
    }

}

class Request extends Thread{
    final private String address;
    final private int port;
    final private int operation;
    final private String threadNum;

    public Request(int port, String address, int operation, String threadNum){
        this.port = port;
        this.address = address;
        this.operation = operation;
        this.threadNum = threadNum;
    }

    public void run(){

        try {
            Socket socket = new Socket(address,port);
            Instant start = Instant.now();

            OutputStream out = socket.getOutputStream();
            PrintWriter writer = new PrintWriter(out, true);
            writer.println(this.operation);

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String msg;
		    StringBuilder serverMsg = new StringBuilder();
           
            String serverResponse;

		    while((msg = in.readLine()) != null) {
                serverMsg.append(msg).append("\n");
            }

            serverResponse = serverMsg.toString();
            Instant stop = Instant.now();
            long time = Duration.between(start, stop).toMillis();

            
            System.out.print("----------------------------------------------------------------------------\n" + threadNum + "'s output:\n" + serverResponse + threadNum + " completed operation(s) in " + time + " ms.\n");


            Client.calculate(time);



        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
