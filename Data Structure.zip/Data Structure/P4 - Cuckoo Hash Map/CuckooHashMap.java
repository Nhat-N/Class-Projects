import java.util.ArrayList;

public class CuckooHashMap<K, V> {
	private int caps;
	private int size = 0;
	private int prime;
	private Entry<K, V>[] table1;
	private Entry<K, V>[] table2;

	CuckooHashMap() {
		caps = 4;
		prime = 10007;
		table1 = new Entry[caps / 2];
		table2 = new Entry[caps / 2];

	}

	CuckooHashMap(int cap) {
		if (cap % 2 == 1) {
			caps = cap + 1;
			prime = 10007;
		} else {
			caps = cap;
			prime = 10007;
		}
		table1 = new Entry[caps / 2];
		table2 = new Entry[caps / 2];

	}

	CuckooHashMap(int cap, int prime) {
		if (cap % 2 == 1) {
			caps = cap + 1;
			this.prime = prime;
		} else {
			caps = cap;
			this.prime = prime;
		}
		table1 = new Entry[caps / 2];
		table2 = new Entry[caps / 2];
	}

	float loadFactor() {

		return (float) ((float) size / (float) caps);
	}

	int size() {
		return size;
	}

	int capacity() {
		return caps;
	}

	V get(K Key) {
		int current = this.h1(Key);
		Entry<K, V> some = table1[current];

		if (some != null && some.getKey() == Key) {
			return some.getValue();
		} else if (table2[this.h2(Key)] != null && table2[this.h2(Key)].getKey() == Key) {
			return table2[this.h2(Key)].getValue();
		} else {
			return null;
		}
	}

	V remove(K key) {
		int current = this.h1(key);
		Entry<K, V> some = table1[current];

		if (some != null && some.getKey() == key) {
			table1[current] = null;
			size--;
			if (this.loadFactor() < (float) .25) {
				this.resize(caps / 2);
			}
			return some.getValue();

		} else if (table2[this.h2(key)] != null && table2[this.h2(key)].getKey() == key) {
			Entry<K, V> temp = table2[this.h2(key)];
			table2[this.h2(key)] = null;
			size--;
			if (this.loadFactor() < (float) .25) {
				this.resize(caps / 2);
			}
			return temp.getValue();
		} else {
			return null;
		}
	}

	V put(K key, V value) {

		Entry<K, V> y = new Entry<K, V>(key, value);
		int loop = -1;
		do {

			// check if the key is in the first table, make sure it is not null first
			if (table1[(this.h1(y.getKey()))] != null && table1[(this.h1(y.getKey()))].getKey() == y.getKey()) {
				Entry<K, V> temp2 = table1[this.h1(y.getKey())];
				table1[(this.h1(y.getKey()))] = y;
				return temp2.getValue();
			}
			// check if the key is in the second table, make sure it is not null first
			else if (table2[this.h2(y.getKey())] != null && table2[this.h2(y.getKey())].getKey() == y.getKey()) {
				Entry<K, V> temp2 = table2[this.h2(key)];
				table2[this.h2(key)] = y;
				return temp2.getValue();
			}
			// Check if the index at table1 is null, set that index to y, increase size by 1
			// and set y to null to leave the loop
			else if (table1[(this.h1(y.getKey()))] == null) {
				table1[(this.h1(y.getKey()))] = y;
				size++;
				y = null;
			}
			// replace the Entry at table1 with the y, and y become the Entry that was
			// replaced
			else {
				Entry<K, V> temp1 = table1[this.h1(y.getKey())];
				table1[(this.h1(y.getKey()))] = y;
				y = temp1;
				// if the index at table2 is null replace it with y and exist the loop
				if (table2[this.h2(y.getKey())] == null) {
					size++;
					table2[this.h2(y.getKey())] = y;
					y = null;
				}
				// else the index at table2 get replace by y, the loop continues, and y becomes
				// the Entry that was replaced
				else {
					temp1 = table2[this.h2(y.getKey())];
					table2[this.h2(y.getKey())] = y;
					y = temp1;
				}
				// if an infinite loop is detected (the tables has been scan more time then the
				// amount of entry possible/size)
				// then the function will rehash, y will be replace with the new Entry (new
				// hashcode of the old Entry key)
				if (loop >= size) {
					this.rehash();
					temp1 = table2[this.h2(y.getKey())];
					y = temp1;
					loop = 0;
					continue;
				}

			}
			loop += 2; // keep count for infinite loop

		} while (y != null);

		if (this.loadFactor() > (float) .50) {
			this.resize(caps * 2);
		}

		return null;

	}

	Iterable<Entry<K, V>> entrySet() {
		ArrayList<Entry<K, V>> some = new ArrayList<>();

		for (int i = 0; i < caps / 2; i++) {
			if (table1[i] != null) {
				some.add(table1[i]);
			}
			if (table2[i] != null) {
				some.add(table2[i]);
			}
		}
		return some;
	}

	Iterable<K> keySet() {
		ArrayList<K> some = new ArrayList<>();

		for (int i = 0; i < caps / 2; i++) {
			if (table1[i] != null) {
				some.add(table1[i].getKey());
			}
			if (table2[i] != null) {
				some.add(table2[i].getKey());
			}
		}
		return some;
	}

	Iterable<V> valueSet() {
		ArrayList<V> some = new ArrayList<>();

		for (int i = 0; i < caps / 2; i++) {
			if (table1[i] != null) {
				some.add(table1[i].getValue());
			}
			if (table2[i] != null) {
				some.add(table2[i].getValue());
			}
		}
		return some;

	}

	void rehash() {
		prime++;
		while (isPrime(prime, 2) != true) {
			prime++;
		}
		this.resize(caps);
	}

	boolean isPrime(int prime, int start) {
		if (start == prime) {
			return true;
		} else if (prime % start == 0) {

			return false;
		} else {
			return isPrime(prime, start + 1);
		}
	}

	void resize(int newCap) {
		if (newCap < 4) {
		} else {
			int oldcap = caps;
			caps = newCap;
			Entry<K, V>[] temp1 = new Entry[caps / 2];
			Entry<K, V>[] temp2 = new Entry[caps / 2];
			for (int i = 0; i < oldcap / 2; i++) {
				if (table1[i] != null) {
					temp1[this.h1(table1[i].getKey())] = table1[i];
				}
				if (table2[i] != null) {
					temp2[this.h2(table2[i].getKey())] = table2[i];
				}
			}

			table1 = temp1;
			table2 = temp2;
		}
	}

	int h1(K key) {
		return ((Math.abs(key.hashCode()) % prime) % (caps / 2));
	}

	int h2(K key) {
		return (((Math.abs(key.hashCode()) / prime) % prime) % (caps / 2));

	}

}
