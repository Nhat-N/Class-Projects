
public class Entry<K,V> {
	
		private K k; 
		private V v; 
		
		public Entry(K key, V value) {
			k = key;
			v = value;
		}
	
	public V getValue(){
		return v;
	}
	public V setValue(V value){
		V old =v ;
		v = value;
		return old;
	}
	public K getKey(){
		return k;
	}
	void setKey(K key){
		k = key;
	}
}
