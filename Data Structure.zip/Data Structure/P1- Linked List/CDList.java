public class CDList<E> implements Cloneable {
	// --------------nested node class------------
	private static class Node<E> {
		private E element;
		private Node<E> prev;
		private Node<E> next;

		public Node(E e, Node<E> p, Node<E> n) {
			element = e;
			prev = p;
			next = n;
		}

		public E getElement() {
			return element;
		}

		public Node<E> getPrev() {
			return prev;
		}

		public Node<E> getNext() {
			return next;
		}

		public void setPrev(Node<E> p) {
			prev = p;
		}

		public void setNext(Node<E> n) {
			next = n;
		}

		public String toString() {
			return "(" + prev.getElement() + "," + element + "," + next.getElement() + ")";
		}
	}

	// ---------------end of nested node class------------

	// Member data
	private Node<E> tail = null;
	private int size = 0;

	public CDList() {
	}

	public CDList(CDList<E> cdl) {
		while (size != cdl.size) {
			addFirst(cdl.last());
			cdl.rotateBackward();
		}
		// the copy constructor
	}

	/*
	 * this will add the last element from the cdl to the first position of the
	 * current/new CDList. Then the cdl rotate backward till the list is at its
	 * original position while adding the current cdl last to the first position
	 * till it reaches head. Then rotate once more so the cdl is in the correct
	 * position. In short it's adding the list in reverse with the next and prev
	 * node following the add(E) rule.
	 */
	public int size() {
		return size;
	}

	public boolean isEmpty() {
		if (size == 0) {
			return true;
		} else {
			return false;
		}
	}

	public E first() {
		if (isEmpty() == true) {
			return null;
		} else {
			return tail.getNext().getElement();
		}
	}

	public E last() {
		if (isEmpty() == true) {
			return null;
		} else {
			return tail.getElement();
		}
	}

	public void rotate() {
		if (isEmpty() == true) {
		} else {
			tail = tail.getNext();
		}
		// tail will be assign to the "head" or tail.getnext
	}

	public void rotateBackward() {

		if (isEmpty() == true) {
		} else {

			tail = tail.getPrev();

		}
		// tail will be assign to the previous node
	}

	public void addFirst(E e) {
		if (size == 0) {
			tail = new Node<>(e, null, null);
			tail.setNext(tail);
			tail.setPrev(tail);
			size++;
		} else {
			Node<E> f = new Node<>(e, tail, tail.getNext());
			tail.getNext().setPrev(f);
			tail.setNext(f);
			size++;
		}
	}

	/*
	 * if the size is empty create a new node with the new element and set prev and
	 * set next equal to itself/the tail node. If it's not empty create a new node with
	 * the new element and set it between the "head" and tail then set the
	 * "head"/tail.getnext prev to equal the new node and the tail set next equal to
	 * the new node
	 */
	public void addLast(E e) {
		addFirst(e);
		tail = tail.getNext();
		// add the new node to the first position and then set tail to the new node or
		// the "head"/ tail.getnext
	}

	public E removeFirst() {

		if (isEmpty() == true) {
			return null;
		} else {
			Node<E> head = tail.getNext();
			Node<E> after = head.getNext();
			tail.setNext(after);
			after.setPrev(tail);
			size--;
			return head.getElement();
		}
	}

	/*
	 * the tail.setNext is set to the node following "head" and the node following head
	 * set prev equal to tail Also create a new node call head that is after the
	 * tail node to return the element.
	 */
	public E removeLast() {
		if (isEmpty() == true) {
			return null;
		} else {
			Node<E> wastail = tail;
			tail.getNext().setPrev(tail.getPrev());
			tail = tail.getPrev();
			tail.setNext(wastail.getNext());
			size--;
			return wastail.getElement();
		}
	}

	/*create a new node call wastail to return the element. tail.getNext() or "head"
	 * set prev equal to the node before tail, tail will equal to the node before, and then set
	 * tail.get next equal to wastail.get next or "head"
	 */
	public CDList<E> clone() {
		CDList<E> testing = new CDList<E>();
		int newsize = size;
		while (newsize != 0) {
			testing.addFirst(this.last());
			this.rotateBackward();
			newsize--;
		}
		return testing;
	}
	/*
	 * Essentially doing the same thing as the copy constructor but a new CDList is
	 * created first called testing and a counter/newsize, that was set to this CDList size,
	 * will continue decrease by 1 until it reaches 0 indicating it has added all node and elements
	 */

	public boolean equals(Object o) {

		CDList<E> test = (CDList<E>) o; // set the object o to be CDList so methods can be call
		CDList<E> testing = test.clone(); // this clone the list, so, removing node doesn't affect the original
		int placement = 0;
		int p2 = 0;
		// these two int is to check if the if(something ==testing.first) statement in
		// the for loop was used
		int newsize = test.size;

		if (this.tail.getElement() == test.tail.getElement()) {
			// check if it's the same element and size beforehand
			if (this.size == test.size) {
				for (int i = 0; i < size; i++) {
					E something = this.last();
					for (int j = 0; j < newsize; j++) {
						if (something == testing.first()) {
							newsize--;
							testing.removeFirst();
							placement++;
							break;
						}
						testing.rotate();
					}
					if (placement == p2) {
						return false;
					}
					p2++;
					this.rotate();
				}
				return true;
			}
		}
		return false;
		/* check all the data in the testing CDList and compare it to the current last
		 * element in the current CDList. If the testing CDList does not contain this
		 * element return false indicated by the if(something ==testing.first())
		 * statement not being use (if it was use placement equal to one more than p2).
		 * if it was use the element gets remove, newsize decrease and placement
		 * increase. then the current CDList list rotate until it has check all the
		 * element and it's in the original position
		 */
	}

	public void attach(CDList cdl) {
		int newsize = cdl.size;
		if (size == 0 || cdl.size == 0) {
		} else {
			while (newsize != 0) {
				this.addLast((E) cdl.first());
				cdl.rotate();
				newsize--;
			}
		}
		// insert cdl after the tail of the current list
		
		// add the first element in the cdl CDList to the last position in the current
		// CDList. Then cdl CDList rotate till all the element is added into the current CDList
		// and it's back to it's original position
	}

	public void removeDuplicates() {
		// remove all elements that happen more than once in the list. If the tail gets
		// deleted, the element immediately before the tail�will become the new tail.

		for (int i = 0; i < size; i++) {

			E something = this.first();
			this.rotate();
			for (int j = 0; j < size-1 ; j++) {
				if (something == this.first()) {
					this.removeFirst();
					j--; 
					continue;
				}
				this.rotate();
			}
			this.rotate();
		}
		
	}
	/*
	 * E something will remember/is equal to the first element in the CDList. Then it will rotate so the first element is 
	 * the one after it. If it's the same remove it then repeat the process until the first element is not the same 
	 * as E something (this is the reason for j-- and continue) ,then analyze the rest of the element in the list
	 * and exist the inner for loop.Then rotate the list so there can be a new first element and repeat the step.
	 * until the it reaches size.
	 */

	public void printList() {
		// prints all elements in the list
		if (size == 0)
			System.out.println("List is empty.");
		else {
			Node<E> walk = tail.getNext();

			while (!(walk.getNext().equals(tail.getNext()))) {
				System.out.print(walk.toString() + ", ");
				walk = walk.getNext();
			}
			System.out.println(walk.toString());
		}
	}
}