import java.net.*;
import java.io.*;
import java.util.Scanner;


public class Multiserver {


	public static void main(String[] args) throws IOException {
	Scanner input = new Scanner(System.in);

	boolean holder;

	int port;
	
	do {
	//add if IP is needed or localhost
	//System.out.print("Please input the IP Address: ");
	//String str= input.next();
	//InetAddress IP = InetAddress.getByName(str);
		
	System.out.print("Please enter the Port number: ");
	port = input.nextInt();
	holder = checkint(port);
	
	} while(holder == false);
	
	
	try(ServerSocket ss = new ServerSocket(port, 100)){
		System.out.println("On Port: " + port + ". Waiting for client" );
		while(true) {		
				Socket socket = ss.accept();
				System.out.println("Accepted client");
				 new ServerThread(socket).start();
		}
	} catch (IOException error) {
        System.out.println("Server exception: " + error.getMessage());
        error.printStackTrace();
    }
	
	
	}
	

	static class ServerThread extends Thread{
		private Socket socket;
		public  ServerThread(Socket socket) {
	        this.socket = socket;
	    }
		
		public void run() {
			String option;
			Process process = null;
			Runtime runt = Runtime.getRuntime();
			try {
			InputStream inStream = socket.getInputStream();
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(inStream));
			option = reader.readLine();

			switch(option) {
			case "1":
				process = runt.exec("date");
				break;
			case "2":
				process = runt.exec("uptime");
				break;
			case "3":
				process = runt.exec("free");
				break;
			case "4":
				process = runt.exec("netstat");
				break;
			case "5":
				process = runt.exec("users");
				break;
			case "6":
				process = runt.exec("ps -aux");
				break;
			default:
				System.out.println("Unknown command specified: " + option);
				System.exit(-1);
			}
				System.out.println("Completed");
				
				BufferedReader temp;
				temp = new BufferedReader(new InputStreamReader(process.getInputStream()));
				
				StringBuilder message = new StringBuilder();
			    for(String i = ""; i != null; i = temp.readLine()) {
			        message.append(i).append("\n");
			    }
			    
			    OutputStream out = socket.getOutputStream();
			    PrintWriter sender = new PrintWriter(out, true);
			    sender.println(message);
			    sender.close();
			    socket.close();

			}catch(IOException error) {
                System.out.println("Server exception: " + error.getMessage());
       			error.printStackTrace();
            }
			
		
			
		}
		
		
	}
	
	
	
	private static boolean checkint(int n) {
		if(n == (int)n)
		{
			return true;
		}
		return false;
	}
	
	
}

