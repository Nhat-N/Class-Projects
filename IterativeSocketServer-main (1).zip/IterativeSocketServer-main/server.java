import java.net.*;
import java.io.*;
import java.util.Scanner;


public class server {


	public static void main(String[] args) throws IOException {
	Scanner input = new Scanner(System.in);
	Process process;
	Runtime runt = Runtime.getRuntime();
	boolean holder;
	String option;
	int port;
	
	do {
	System.out.print("Please enter the Port number: ");
	port = input.nextInt();
	holder = checkint(port);
	} while(holder == false);
	
	ServerSocket ss = new ServerSocket(port ,25);			
			
	System.out.println("Waiting for client");
	
	do {
		
	Socket socket = ss.accept();
	System.out.println("Accepted client");
	
	InputStream inStream = socket.getInputStream();
	BufferedReader reader = new BufferedReader(new InputStreamReader(inStream));
	option = reader.readLine();
	
	
	switch(option) {
	case "1":
		process = runt.exec("date");
		break;
	case "2":
		process = runt.exec("uptime");
		break;
	case "3":
		process = runt.exec("free");
		break;
	case "4":
		process = runt.exec("netstat");
		break;
	case "5":
		process = runt.exec("users");
		break;
	case "6":
		process = runt.exec("ps -aux");
		break;
	default:
		System.out.println("Unknown command specified: " + option);
		socket.close();
		input.close();
		holder = false;
		return;
	}
	
	System.out.println("Completed, waiting for next client");
	
	BufferedReader temp;
	temp = new BufferedReader(new InputStreamReader(process.getInputStream()));
	
	StringBuilder message = new StringBuilder();
    for(String i = ""; i != null; i = temp.readLine()) {
        message.append(i).append("\n");
    }
    
    OutputStream out = socket.getOutputStream();
    PrintWriter sender = new PrintWriter(out, true);
    sender.println(message);
    sender.close();
    
	}while(holder == true);
	
	
	
	input.close();
	
	}
	
	private static boolean checkint(int n) {
		if(n == (int)n)
		{
			return true;
		}
		return false;
	}
	
	
}
